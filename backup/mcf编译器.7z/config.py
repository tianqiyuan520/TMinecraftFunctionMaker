from read_config import read_json,Custom_functions

defualt_PATH = '' #默认路径
defualt_STORAGE = '' # STORAGE
scoreboard_objective = '' # 默认记分板
defualt_NAME = '' # 项目名称
custom_functions = Custom_functions.read() # 自定义函数调用表

cfg = read_json.read('config.json')
scoreboard_objective = cfg['scoreboard_objective']
defualt_NAME = cfg['name']
defualt_PATH = cfg['path']+"data\\"+cfg['name'] + '\\'
defualt_STORAGE = cfg['name']+":system"