import tkinter
from tkinter import ttk
window = tkinter.Tk()
window.title('标题')
window.geometry('300x300')

window.mainloop()
