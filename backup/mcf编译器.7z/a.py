class A:
    ...
import math
a = A

a.prit(1)
math.cos()