import os
import re
from typing import Union

def get() -> Union[float, int]:
    return x

