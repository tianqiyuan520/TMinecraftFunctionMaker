class MC_commands:
    def __init__(self) -> None:
        pass