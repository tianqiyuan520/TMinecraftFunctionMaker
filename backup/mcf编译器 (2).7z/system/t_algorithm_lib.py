def example(input0):
    """样例
    
测试"""
    import math
    return math.cos(input0)
