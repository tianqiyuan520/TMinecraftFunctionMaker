def run(command:str = "say hello world",flag:str="result"):
    """
        - 执行mc指令
        
        example:
        
        run('say hi') #将在mcfunction写入say hi
        
        a = run('say hi') #将在mcfunction写入execute store result ... run say hi . 将命令执行结果返回给变量a
        
        a = run('say hi','success') #将在mcfunction写入execute store success ... run say hi . 将命令执行结果返回给变量a
        
    """

    return 0.0